package com.example.birthapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home) // Ensure this matches the XML layout file name

        // Define your buttons
        val btnProfile: Button = findViewById(R.id.btnProfile)
        val btnBirthCertificate: Button = findViewById(R.id.btnBirthCertificate)
        val btnDeathCertificate: Button = findViewById(R.id.btnDeathCertificate)
        val btnChat: Button = findViewById(R.id.btnChat)  // Add this for the ChatBot button

        // Define buttons for health and car insurance
        val btnHealthInsurance: Button = findViewById(R.id.healthinscurance)
        val btnCarInsurance: Button = findViewById(R.id.carinsurance)

        // Set up click listeners for existing buttons
        btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        btnBirthCertificate.setOnClickListener {
            startActivity(Intent(this, BirthCertificateActivity::class.java))
        }

        btnDeathCertificate.setOnClickListener {
            startActivity(Intent(this, DeathCertificateActivity::class.java))
        }

        // Set up click listener for btnChat to launch ChatBotActivity
        btnChat.setOnClickListener {
            startActivity(Intent(this, ChatBotActivity::class.java))  // Launch ChatBotActivity
        }

        // Set up click listener for btnHealthInsurance to open Health Insurance website
        btnHealthInsurance.setOnClickListener {
            val healthInsuranceUrl = "https://www.icicilombard.com/health-insurance/" // Replace with your health insurance website
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(healthInsuranceUrl))
            startActivity(intent) // Open website in the default browser
        }

        // Set up click listener for btnCarInsurance to open Car Insurance website
        btnCarInsurance.setOnClickListener {
            val carInsuranceUrl = "https://www.icicilombard.com/motor-insurance/car-insurance" // Replace with your car insurance website
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(carInsuranceUrl))
            startActivity(intent) // Open website in the default browser
        }
    }
}
