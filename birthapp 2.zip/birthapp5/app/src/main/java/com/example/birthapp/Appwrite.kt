package com.example.birthapp  // Make sure this matches your package name

import android.content.Context
import io.appwrite.Client
import io.appwrite.ID
import io.appwrite.models.Session
import io.appwrite.models.User
import io.appwrite.services.Account

object Appwrite {
    lateinit var client: Client
    lateinit var account: Account

    fun init(context: Context) {
        client = Client(context)
            .setEndpoint("https://cloud.appwrite.io/v1") // API Endpoint
            .setProject("66f45171002bbc202722") // Your Project ID

        account = Account(client)
    }

    // Method to send SMS and create a phone token
    suspend fun createPhoneToken(phone: String): String {
        val token = account.createPhoneToken(
            userId = ID.unique(),
            phone = phone
        )
        return token.userId // Return the user ID for later use
    }

    // Method to create a session using the secret received via SMS
    suspend fun createSession(userId: String, secret: String): Session {
        return account.createSession(
            userId = userId,
            secret = secret
        )
    }

    // Method to log out
    suspend fun onLogout() {
        account.deleteSession("current")
    }
}
