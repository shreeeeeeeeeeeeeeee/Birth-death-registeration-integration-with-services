package com.example.birthapp

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class ChatBotActivity : AppCompatActivity() {

    // Declare ImageViews for questions and answers
    private lateinit var question1: ImageView
    private lateinit var question2: ImageView
    private lateinit var question3: ImageView
    private lateinit var question4: ImageView
    private lateinit var question5: ImageView

    private lateinit var ans1: ImageView
    private lateinit var ans2: ImageView
    private lateinit var ans3: ImageView
    private lateinit var ans4: ImageView
    private lateinit var ans5: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatbot)

        // Initialize the views
        question1 = findViewById(R.id.question1)
        question2 = findViewById(R.id.question2)
        question3 = findViewById(R.id.question3)
        question4 = findViewById(R.id.question4)
        question5 = findViewById(R.id.question5)

        ans1 = findViewById(R.id.ans1)
        ans2 = findViewById(R.id.ans2)
        ans3 = findViewById(R.id.ans3)
        ans4 = findViewById(R.id.ans4)
        ans5 = findViewById(R.id.ans5)

        // Set click listeners for the question images
        question1.setOnClickListener {
            showAnswer(ans1)
        }
        question2.setOnClickListener {
            showAnswer(ans2)
        }
        question3.setOnClickListener {
            showAnswer(ans3)
        }
        question4.setOnClickListener {
            showAnswer(ans4)
        }
        question5.setOnClickListener {
            showAnswer(ans5)
        }
    }

    // Function to show the corresponding answer and hide others
    private fun showAnswer(answerToShow: ImageView) {
        // Hide all answers first
        ans1.visibility = View.GONE
        ans2.visibility = View.GONE
        ans3.visibility = View.GONE
        ans4.visibility = View.GONE
        ans5.visibility = View.GONE

        // Show the clicked answer
        answerToShow.visibility = View.VISIBLE
    }
}
