package com.example.birthapp

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import io.appwrite.Client
import io.appwrite.services.Databases
import io.appwrite.ID
import kotlinx.coroutines.Dispatchers
import android.content.SharedPreferences

class ProfileActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var database: Databases
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        Log.d("ProfileActivity", "onCreate started")

        // Initialize UI components
        nameEditText = findViewById(R.id.name_in_profile)
        emailEditText = findViewById(R.id.EmailAddress)
        saveButton = findViewById(R.id.button)

        // Initialize Appwrite Client and Databases service
        val client = Client(this)
        client.setEndpoint("https://cloud.appwrite.io/v1")
            .setProject("66f45171002bbc202722")
            .setSelfSigned(true)

        database = Databases(client)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserPreferences", MODE_PRIVATE)

        // Load previously saved data and set input fields
        loadUserProfile()

        // Set up save button click listener
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val email = emailEditText.text.toString()

            Log.d("ProfileActivity", "Save button clicked. Name: $name, Email: $email")

            if (name.isNotEmpty() && email.isNotEmpty()) {
                Log.d("ProfileActivity", "Fields are valid. Saving profile.")
                saveUserProfile(name, email) // Save profile to Appwrite database
                saveUserLocally(name, email) // Save profile locally

                // Make the fields read-only after saving
                setFieldsReadOnly()
            } else {
                Log.e("ProfileActivity", "Error: Please fill in both fields.")
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to save profile information to the Appwrite database
    private fun saveUserProfile(name: String, email: String) {
        Log.d("ProfileActivity", "saveUserProfile started. Saving profile for $name with email $email.")

        GlobalScope.launch(Dispatchers.Main) {
            try {
                val data = mapOf("name" to name, "email" to email)

                Log.d("ProfileActivity", "Preparing to save profile in database: $data")

                // Save profile in the database
                val document = database.createDocument(
                    databaseId = "66f45171002bbc202722",  // Database ID
                    collectionId = "6736c094000a9367da13",  // Collection ID
                    data = data,
                    documentId = ID.unique()  // Auto-generate a unique document ID
                )

                // Log successful document creation
                Log.d("ProfileActivity", "Profile saved successfully. Document ID: ${document.id}")

                // Notify user that the profile was saved
                Toast.makeText(this@ProfileActivity, "Profile saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e("ProfileActivity", "Error saving profile: ${e.message}")
                Toast.makeText(this@ProfileActivity, "Error saving profile: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to save name and email locally using SharedPreferences
    private fun saveUserLocally(name: String, email: String) {
        Log.d("ProfileActivity", "saveUserLocally started. Saving name: $name and email: $email")

        val editor = sharedPreferences.edit()
        editor.putString("user_name", name) // Save the name
        editor.putString("user_email", email) // Save the email
        editor.apply()

        Log.d("ProfileActivity", "Name and Email saved locally.")
    }

    // Function to load user profile from SharedPreferences
    private fun loadUserProfile() {
        Log.d("ProfileActivity", "Loading user profile from SharedPreferences")

        // Retrieve saved name and email
        val savedName = sharedPreferences.getString("user_name", null)
        val savedEmail = sharedPreferences.getString("user_email", null)

        // If data exists, populate fields and make them read-only
        if (savedName != null && savedEmail != null) {
            nameEditText.setText(savedName)
            emailEditText.setText(savedEmail)
            setFieldsReadOnly()
        }
    }

    // Function to set input fields as read-only
    private fun setFieldsReadOnly() {
        Log.d("ProfileActivity", "Setting input fields to read-only")

        nameEditText.isFocusable = false
        nameEditText.isFocusableInTouchMode = false
        nameEditText.isClickable = false

        emailEditText.isFocusable = false
        emailEditText.isFocusableInTouchMode = false
        emailEditText.isClickable = false

        // Optionally disable the save button
        saveButton.isEnabled = false
    }
}
