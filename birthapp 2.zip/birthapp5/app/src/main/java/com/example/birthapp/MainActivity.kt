package com.example.birthapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import io.appwrite.Client
import io.appwrite.services.Account
import io.appwrite.ID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var client: Client
    private lateinit var account: Account

    // Declare state variables
    private var userId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Set your XML layout file name here

        // Initialize the Appwrite client
        client = Client(this)
            .setEndpoint("https://cloud.appwrite.io/v1")
            .setProject("66f45171002bbc202722") // Replace with your project ID

        account = Account(client)

        // Initialize views
        val sendOtpButton: Button = findViewById(R.id.sendOtpButton)
        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val phoneEditText: EditText = findViewById(R.id.phoneEditText)

        // Set up the send OTP button click listener
        sendOtpButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val phone = phoneEditText.text.toString()
            sendOtp(phone, name)
        }
    }

    private fun sendOtp(phone: String, name: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Send OTP and create user account
                val token = account.createPhoneToken(ID.unique(), phone)
                userId = token.userId // Set userId

                runOnUiThread {
                    Toast.makeText(this@MainActivity, "OTP sent to $phone", Toast.LENGTH_SHORT).show()
                    // Navigate to OTP verification screen
                    val intent = Intent(this@MainActivity, OTPVerificationActivity::class.java)
                    intent.putExtra("userId", userId) // Pass userId to the next activity
                    startActivity(intent)
                    finish() // Close the current activity
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
